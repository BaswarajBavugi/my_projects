import { Component } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../service/api.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent {
  adminForm!:FormGroup;
  packageId:any; 
  constructor(private router: Router, private readonly apiService: ApiService, private route: ActivatedRoute ) {
    this.packageId = this.route.snapshot.paramMap.get('packageId')

  }
  ngOnInit(): void {
     this.adminForm=new FormGroup(
      {
        location:new FormControl(''),
        description:new FormControl(''),
        img:new FormControl(''),
        price:new FormControl(null),
        day:new FormControl(0)
      }
     )
     if(this.packageId)
     this.updateForm()
  }
  updateForm(){
    this.apiService.getPackage(this.packageId).subscribe((res:any) =>{
      if(res){
        this.adminForm.setValue({
          location:res.location,
          description:res.description,
          img:res.img,
          price:res.price,
          day:res.day
        })
      }
    })
  }
  onClickAddPackage(){
    if(this.adminForm.valid){
      this.apiService.addPackage(this.adminForm.value).subscribe(res =>{
        if(res){
          this.router.navigate(['/package'])
        }
      })
    }
  }
  onClickUpdatePackage(){
    if(this.adminForm.valid){
      this.apiService.updatePackage(this.adminForm.value, this.packageId).subscribe(res =>{
        if(res){
          this.router.navigate(['/package'])
        }
      })
    }
  }
}
