import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/service/api.service';

@Component({
  selector: 'app-admin-view-user',
  templateUrl: './admin-view-user.component.html',
  styleUrls: ['./admin-view-user.component.css']
})
export class AdminViewUserComponent implements OnInit{

  users:any;

  constructor(private apiService:ApiService){}


  ngOnInit(): void {

    this.apiService.getAllUser().subscribe(data=>{
       this.users=data;
    })
    
  }



}
