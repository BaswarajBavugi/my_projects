import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ApiService } from 'src/app/service/api.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent {


@Input() product: any;
@Output() removePackage: EventEmitter<any> = new EventEmitter();

userId:any;

isAdmin = false;

constructor(public router:Router,private apiService: ApiService,private route:ActivatedRoute){
  this.isAdmin = this.apiService.getCurrentUser()?.role == "ADMIN" || false;

  route.queryParams.subscribe(params =>{
    this.userId = params['userId']
  })

}

deletePackage(packageId:any){
 this.apiService.deletePackage(packageId).subscribe(res =>{
  this.removePackage.emit(packageId)
 },(error) =>{
  this.removePackage.emit(packageId)
 })
}



bookTour(packageId:any){
  console.log(packageId)
  this.router.navigate(["/booking"],{queryParams:{id:packageId,uId:this.userId}})
}

 
}
