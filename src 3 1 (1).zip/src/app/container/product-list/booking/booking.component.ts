import { HttpClient } from '@angular/common/http';
import { Component, Input } from '@angular/core';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from 'src/app/service/api.service';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent {
  BookingForm: any = FormGroup;

  travName:any;
  number: any;
  package: any;
  date: any;
  memberNumber: any;
  userId: any;
  packageId: any;

  constructor(private router: Router, private http: HttpClient, private apiService: ApiService, private fb: FormBuilder, private route: ActivatedRoute) {
      this.packageId = this.route.snapshot.paramMap.get('id');
      this.userId = this.route.snapshot.paramMap.get('uId');
   }

  ngOnInit(): void {
    this.BookingForm = new FormGroup(
      {
        travName: new FormControl(''),
        number: new FormControl(''),
        package: new FormControl(''),
        date: new FormControl(''),
        memberNumber: new FormControl(''),
      })

    
  }

  book(bookingData: any) {

    const bodyData = {
      travName: this.BookingForm.value.travName,
      number: this.BookingForm.value.number,
      date: this.BookingForm.value.date,
      memberNumber: this.BookingForm.value.memberNumber,
      username: this.userId,
      packageId: this.packageId

    };

    this.apiService.booking(bodyData).subscribe((resultData: any) => {
      console.log(bodyData)
      console.log(resultData);
      if (resultData) {
        alert("Employee Booking Successfully");
        this.router.navigateByUrl('/package');

      } else {
        alert('Booking successfully. Now you can login !!!')
      }
    });
  }
}
