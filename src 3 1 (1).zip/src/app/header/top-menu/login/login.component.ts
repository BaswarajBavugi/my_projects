import { HttpClient } from '@angular/common/http';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/service/api.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{
   loginForm!:FormGroup; 
  constructor(private router: Router, private readonly apiService: ApiService) {}
  ngOnInit(): void {
     this.loginForm=new FormGroup(
      {
        email:new FormControl(''),
        password:new FormControl('')
      }
     )
  }
  
 
  login() {
    const loginData = this.loginForm.value
    this.apiService.loginUser(loginData).subscribe((res: any) => {
      this.apiService.updateCurrentUser(res)
      sessionStorage.setItem('access_token',res.jwtToken)
      sessionStorage.setItem('uId',res.id)
      this.apiService.updateCommonHeader()
      this.router.navigate(['/package'],{queryParams:{userId:res.username}});

    })
  }
}
