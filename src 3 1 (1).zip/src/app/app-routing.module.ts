import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { ProductListComponent } from './container/product-list/product-list.component';
import { LoginComponent } from './header/top-menu/login/login.component';
import { RegistrationComponent } from './header/top-menu/registration/registration.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { BookingComponent } from './container/product-list/booking/booking.component';
import { ForgotPasswordComponent } from './header/top-menu/login/forgot-password/forgot-password.component';
import { HomeComponent } from './home/home.component';
import { FooterComponent } from './footer/footer.component';
import { HistoryComponent } from './history/history.component';
import { AdminComponent } from './admin/admin.component';
import { AdminViewUserComponent } from './admin/admin-view-user/admin-view-user.component';
import { AdminViewBookingComponent } from './admin/admin-view-booking/admin-view-booking.component';
import { AuthGuardGuard } from './guards/auth-guard.guard';
 

const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'package',component:ProductListComponent,
   canActivate:[AuthGuardGuard]},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegistrationComponent},
  {path:'booking',component:BookingComponent,canActivate:[AuthGuardGuard]},
  {path:'forgot-password',component:ForgotPasswordComponent},
  {path:'footer',component:FooterComponent},
  {path:'history',component:HistoryComponent,canActivate:[AuthGuardGuard]},
  {path:'add-package',component:AdminComponent,canActivate:[AuthGuardGuard]},
  {path:'view-user',component:AdminViewUserComponent,canActivate:[AuthGuardGuard]},
  {path:'view-booking',component:AdminViewBookingComponent,canActivate:[AuthGuardGuard]},
  {path:'edit-package/:packageId',component:AdminComponent,canActivate:[AuthGuardGuard]},
  {path:'**',component:PagenotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
