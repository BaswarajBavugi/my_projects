package com.tourism.Travel_Buddy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelBuddyApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelBuddyApplication.class, args);
	}

}
