package com.tourism.Travel_Buddy.services;

import org.springframework.stereotype.Service;

@Service
public class AdminService {


}
