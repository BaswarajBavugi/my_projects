package com.tourism.Travel_Buddy.model;

public class Status {

    public boolean status;

    public Status(boolean status) {
        this.status = status;
    }
}
