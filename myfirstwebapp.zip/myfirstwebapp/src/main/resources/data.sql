insert into todo(id,username,description,target_date,done)values (1001,'Baswaraj','Learn DSA',CURRENT_DATE(),false);
insert into todo(id,username,description,target_date,done)values (1002,'Baswaraj','Learn OS',CURRENT_DATE(),false);
insert into todo(id,username,description,target_date,done)values (1003,'Baswaraj','Learn DBMS',CURRENT_DATE(),false);
insert into todo(id,username,description,target_date,done)values (1004,'Baswaraj','Learn OOPS',CURRENT_DATE(),false);
insert into todo(id,username,description,target_date,done)values (1005,'Baswaraj','Learn Clouds',CURRENT_DATE(),false);