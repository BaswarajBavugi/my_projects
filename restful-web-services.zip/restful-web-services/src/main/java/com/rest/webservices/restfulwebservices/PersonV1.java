package com.rest.webservices.restfulwebservices;

public class PersonV1 {

	private String fullName;

	public PersonV1(String fullName) {
		 this.fullName=fullName;
	}

	public String getfullName() {
		return fullName;
	}
 

}
