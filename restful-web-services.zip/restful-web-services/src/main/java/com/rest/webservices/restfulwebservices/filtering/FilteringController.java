package com.rest.webservices.restfulwebservices.filtering;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;

@RestController
public class FilteringController {

	@GetMapping("/filter")
	public MappingJacksonValue filtering() {
		Somebean somebean=new Somebean("value1","value2","value3");
		//Dynamic FIltering
		MappingJacksonValue mappingJacksonValue=new MappingJacksonValue(somebean);
		SimpleBeanPropertyFilter filter=SimpleBeanPropertyFilter.filterOutAllExcept("field1","field2");
		FilterProvider filters=new SimpleFilterProvider().addFilter("SomebeanFilter", filter);
		mappingJacksonValue.setFilters(filters);
		
		return mappingJacksonValue;
	}
	
	@GetMapping("/filter-list")
	public MappingJacksonValue filteringList(){
		List<Somebean> list=(List<Somebean>) Arrays.asList(new Somebean("value1","value2","value3"),new Somebean("value4","value5","value6"),
				new Somebean("value7","value8","value9"));
		//Dynamic Filtering
		MappingJacksonValue mappingJacksonValue=new MappingJacksonValue(list);
		SimpleBeanPropertyFilter filter=SimpleBeanPropertyFilter.filterOutAllExcept("field3");
		FilterProvider filters=new SimpleFilterProvider().addFilter("SomebeanFilter", filter);
		mappingJacksonValue.setFilters(filters);
		return mappingJacksonValue;
	}
}
