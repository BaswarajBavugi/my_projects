package com.rest.webservices.restfulwebservices;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class VersioningPersonController {

//	URI Versioning
	@GetMapping("v1/persons")
	public PersonV1 UriV1() {
		return new PersonV1("Baswaraj Bavugi");
	}
	
	@GetMapping("v2/persons")
	public PersonV2 UriV2() {
		return new PersonV2(new Name("Baswaraj","Bavugi"));
	}
	
//	Request Params Versioning
	@GetMapping(path="/persons",params="version=1")
	public PersonV1 paramV1() {
		return new PersonV1("Baswaraj");
	}
	
	@GetMapping(path="/persons",params="version=2")
	public PersonV2 paramV2() {
		return new PersonV2(new Name("Baswaraj","Bavugi"));
	}
	
//	headers versioning
	@GetMapping(path="/persons",headers="X-API-VERSION=1")
	public PersonV1 headersV1() {
		return new PersonV1("Baswaraj Bavugi");
	}
	@GetMapping(path="persons",headers="X=2")
	public PersonV2 headersV2() {
		return new PersonV2(new Name("Baswaraj","Bavugi"));
	}
	
//	Accept header Versioning(produces)
	@GetMapping(path="/persons",produces="application/v1+json")
	public PersonV1 producesV1() {
		return new PersonV1("Baswaraj Bavugi");
	}
	@GetMapping(path="/persons",produces="application/v2+json")
	public PersonV2 producesV2() {
		return new PersonV2(new Name("Baswaraj","Bavugi"));
	}
}
