import FirstComponent from "./FirstComponent";
import FourthComponent, { FifthComponent } from "./FourthComponent";
import LearningJSComponent from "./LearningJSComponent";
import SecondComponenet from "./SecondComponent";
import ThirdComponent from "./ThirdComponent";

export default function LearningComponent(){
    return (
        <div className="LearningComponent">
            Learning Component
            <FirstComponent />
            <SecondComponenet/>
            <ThirdComponent/>
            <FourthComponent/>
            <FifthComponent></FifthComponent>
            <LearningJSComponent/>
        </div>
    )
}