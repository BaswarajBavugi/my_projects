const person={
    name:"Baswaraj",
    address:{
        village : "Thurkapally",
        town : "Narayankhed",
        city : "Hyderabad"
    },
    social_media:['instagram','facebook','linkedin'],
    print_profiles:function(){
        return this.social_media.map((profile)=>profile+" ")
    }
    
}
export default function LearningJSComponent(){
    return (
        <div className="LearningJSComponent">
             {person.print_profiles() }
        </div>
    )
}