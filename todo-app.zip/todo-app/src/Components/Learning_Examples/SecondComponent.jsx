export default function SecondComponenet(){
    return(
      <div className='SecondComponent'>
        Second Component    
        </div>
    )
  }