import { useState } from "react";
import CounterComponent from "../Counter/CounterComponent";
import "../Counter/CounterComponent.css"

export default function CounterConatinerComponent(){
    const [count,setCount]=useState(0);
    function parentComponentIncreament(by){
        setCount(count+by);
    }
    function parentComponentDecreament(by){
        setCount(count-by);
    }
    function reset(){
        setCount(0);
    }
    return (
      
        <div className="CounterConatinerComponent">
            <CounterComponent incMethod={parentComponentIncreament} decMethod={parentComponentDecreament}/>
            <CounterComponent by={2} incMethod={parentComponentIncreament} decMethod={parentComponentDecreament}/>
            <CounterComponent by={5} incMethod={parentComponentIncreament} decMethod={parentComponentDecreament}/>
            <div className="count">{count}</div>
            <div>
            <button className="resetButton"    onClick={reset}>reset</button>
            </div>
        </div>
    )
}