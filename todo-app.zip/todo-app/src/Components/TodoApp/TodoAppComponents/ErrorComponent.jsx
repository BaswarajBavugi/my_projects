function ErrorComponent(){
    return(
        <div className='errorComponent'>
            <h1>We are working really hard</h1>
            <div>Apologies for 404. Reach out to our team at ABC-DEF-GHI</div>
        </div>
    )
}
export default ErrorComponent;