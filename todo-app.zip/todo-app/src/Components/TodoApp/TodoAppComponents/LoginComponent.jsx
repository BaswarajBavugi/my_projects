import { useState } from 'react'
 import { useNavigate } from 'react-router-dom';
import {  useAuth } from '../security/AuthContext';

function LoginComponent(){

   

    const [username,setUsername]=useState("");
    function handleUsernameChange(event){
         setUsername(event.target.value);
    }

    const [password,setPassword]=useState('');
    function handlePasswordChange(event){
         setPassword(event.target.value);
    }

     const [showErrorMessage,setShowErrorMessage]=useState(false);

    const navigate=useNavigate();
    const authContext=useAuth();
      function handleSubmit(){
        if(authContext.login(username,password)){
            navigate(`/welcome/${username}`)
        }
        else{
             setShowErrorMessage(true);
        }
     }

    return (
        <div className="container">
             <h1>Time to login</h1>
             {showErrorMessage && <div className='errorMessage'>Authentication failed. Please check your credentials</div>}
            <div className='card w-75'>
            <form className='m-3'>
                <div>
                    <label htmlFor="userName">User Name:</label>
                    <input type="text" id="userName" className='form-control' name="username" value={username} onChange={handleUsernameChange}/>
                </div>
                <div>
                    <label htmlFor="pwd">Password:</label>
                    <input type="password" id="pwd" className='form-control ' name="password" value={password} onChange={handlePasswordChange}/>
                </div>
                <div>
                    <button type="submit" onClick={handleSubmit} className='btn btn-success mt-2 form-control'>login</button>
                </div>
            </form>
            </div>
        </div>    
    )
  
}

export default LoginComponent;