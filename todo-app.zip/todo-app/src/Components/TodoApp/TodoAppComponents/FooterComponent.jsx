// import '../TodoApp.css'

 

export default function FooterComponent(){

     
    return (
        <footer className='footer'>
            <div className='container'>
            <hr/>
                 Footer
            </div>
        </footer>
    )
}