function LogoutComponent(){
    return (
        <div className='LogoutComponent'>
        </div>
    )
}
export default LogoutComponent;