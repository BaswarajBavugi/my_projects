import { Link, useParams } from "react-router-dom";

function WelcomeComponent(){
    // const params=useParams();
    const {username}=useParams();
    return (
        <div className='container'>
            <h1>Welcome {username}</h1>
            <div>Manage your todos <Link to="/todos">here</Link></div>
        </div>
    )
}

export default WelcomeComponent;