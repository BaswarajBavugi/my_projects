export default function ListTodosComponent(){
    const today=new Date();
    const targetDate=new Date(today.getFullYear()+2,today.getMonth(),today.getDay()).getFullYear();
    const todos=[
        {id:1,description:"Learn AWS",targetDate:targetDate,done:false},
        {id:2,description:"Learn React",targetDate:targetDate,done:false},
        {id:3,description:"Learn Spring Boot",targetDate:targetDate,done:false},
        {id:4,description:"Learn DSA",targetDate:targetDate,done:false},
    ]
    return(
        <div className='container ListTodosComponent'>
            <h1>Your Todos are</h1>
            <div>
                <table className='table'>
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Description</th>
                            <th>Target Date</th>
                            <th>Is done?</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            todos.map(todo=>
                                <tr key={todo.id}>
                                    <td>{todo.id}</td>
                                    <td>{todo.description}</td>
                                    <td>{todo.targetDate.toString()}</td>
                                    <td>{todo.done.toString()}</td>
                                </tr>
                            )
                        }
                        
                    </tbody>
                </table>
            </div>
        </div>
    )
}