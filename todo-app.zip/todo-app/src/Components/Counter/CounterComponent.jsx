// import { useState } from "react";
import "./CounterComponent.css"
// import {propTypes} from 'prop-types'

export default function CounterComponent({by,incMethod,decMethod}){
 
// const [count,setCount]=useState(0);
// function increamentBy(){
//     incMethod(by);
// }
// function decreamentBy(){
//     // setCount(count-by);
//     decMethod(by);
// }
 
    return (
        <div className="CounterComponent">
            <div>
                <button className="counterButton"    onClick={()=>incMethod(by)}>+{by}</button>
                <button className="counterButton"    onClick={()=>decMethod(by)}>-{by}</button>
            </div> 
            {/* <div className="count">{count}</div> */}
             
        </div>
    )
}
// CounterComponent.propTypes={
//     by: propTypes.number
// }
 
CounterComponent.defaultProps={
    by:1
}