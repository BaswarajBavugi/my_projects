let url='https://dog.ceo/api/breeds/image/random';

async function getDogImgs(){
    try {
        let response=await axios.get(url);
        // console.log(response.data.message);
        return response.data.message;
    } catch (error) {
        console.log("Error - ",error)
    }
    
}

let btn=document.querySelector('button');
let pic=document.querySelector('img');
async function firstImage(){
    let image= await getDogImgs();
    console.log(image);
    pic.setAttribute('src',image);
}
firstImage();  
btn.addEventListener('click',async ()=>{
    let image=await getDogImgs();
    console.log(image);
    pic.setAttribute('src',image);
});