let url="https://catfact.ninja/fact";

// fetch(url)
//     .then((response)=>{
//         console.log(response);
//         // console.log(response.json());
//         return response.json() // it is a promise
//     })
//     .then((data)=>{
//         console.log(data.fact);
//         return fetch(url);
//     })
//     .then((response)=>{
//         return response.json();
//     })
//     .then((data2)=>{
//         console.log(data2.fact);
//     })
//     .catch((error)=>{
//         console.log(error);
//     });

// console.log("API calls are async")

async function getCalls(){
    try {
        //first call
    let response =await fetch(url);
    // console.log(response);
    let data =await response.json();
    // console.log(data.fact);
    return data.fact;

    // //second call
    // response =await fetch(url);
    // // console.log(response);
    // data =await response.json();
    // console.log(data.fact);

    } catch (error) {
        console.log(error);
        return "NO Fact";
    }
    console.log("API calls are async");
}
// getCalls();

let btn=document.querySelector('button');
let res=document.querySelector('#response');

async function firstFact(){
    let fact=await getCalls();
    res.innerHTML=fact;
}
firstFact();

btn.addEventListener('click',async ()=>{
    let fact= await getCalls();
    res.innerHTML=fact;
})
