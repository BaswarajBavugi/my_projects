let url="https://icanhazdadjoke.com/";


async function getCall(){
    const config={headers:{Accept:"application/json"}};
    let response=await axios.get(url,config); 
    console.log(response.data.joke);
}