let url="https://catfact.ninja/fact";


async function getAPICalls(){
    try {
         
        let response= await axios.get(url)
        // console.log(response.data);
        return response.data.fact;
    } catch (error) {
        console.log("Error - ",error)
        return "No Fact";
    }
}

// getAPICalls();

let btn=document.querySelector("button");
let res=document.querySelector("#response");

async function firstFact(){
    let fact=await getAPICalls();
    res.innerHTML=fact;
}
firstFact();

btn.addEventListener('click',async ()=>{
    let fact= await getAPICalls();
    res.innerHTML=fact;
})