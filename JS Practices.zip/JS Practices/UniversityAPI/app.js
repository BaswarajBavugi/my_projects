let url='http://universities.hipolabs.com/search?country='

// let country='india'

async function getCalls(country){
    let response= await axios.get(url+country)
    // console.log(response.data);
    return response.data;
}

let btn=document.querySelector('button');
let cntry=document.querySelector('#country');
let ul=document.querySelector('ul');
let h2=document.createElement('h2');

btn.addEventListener('click',async ()=>{
    let country=cntry.value;
    h2.innerText=`Universities of ${country}`;
    btn.insertAdjacentElement('afterend',h2);
    cntry.value="";
    let colleges=await getCalls(country);
    console.log(colleges);
    showCollegeName(colleges);
})

function showCollegeName(colleges){
   ul.innerText='';
    for(college of colleges){
        console.log(college.name);
        let li=document.createElement('li');
        li.innerText=college.name;
        ul.appendChild(li);
      
    }
}