let gameSeq=[];
let userSeq=[];
var highestScore=0;


let started=false;
let level=0;

h2=document.querySelector('h2');

h4=document.querySelector('h4');


document.addEventListener('click',function(){
    
    if(started==false){
        console.log("Game started");
        started=true;
        levelUp();
    } 
});


let btns=["red","green","blue","black"];
function levelUp()
{
    userSeq=[];
    level++;
   
    h2.innerText=`Level ${level}`;
    
    let rIndex=Math.floor(Math.random()*4);
    let rColor=btns[rIndex];
    let rBtn=document.querySelector(`.${rColor}`);
    //
    gameSeq.push(rColor);


    btnFlash(rBtn);
}

function btnFlash(btn){
    btn.classList.add('flash');
 setTimeout(function(){
    btn.classList.remove('flash');
 },100)
}

let allBtns = document.querySelectorAll('.btn');
for(btn of allBtns){
    btn.addEventListener('click',btnPress);
}
 
function btnPress(){
    let btn=this;
    btnFlash(btn);

    let userColor = btn.getAttribute('id');
    userSeq.push(userColor);

    checkAns(userSeq.length-1);
}

function checkAns(idx){
    if(gameSeq[idx]===userSeq[idx]){
        // console.log("Good going");
        if(gameSeq.length===userSeq.length){
             setTimeout(levelUp,1000);
        }
    }
    else{
        
        h2.innerText=`Game Over! Your score is ${level}. 
        Press any key to restart`;
        // console.log(gameSeq);
        // console.log(userSeq);
        if(highestScore<level){
            highestScore=level;
            console.log(highestScore);
            h4.innerText=`Highest score till now is ${highestScore}`; 
        }
        setTimeout(function(){
            restart();
        },0);
         
        
        
    }
    
}

function restart(){  
    started=false;
    level=0;
    gameSeq=[];
    userSeq=[];
    
}
// let h4=document.createElement('h4');
// h4.innerText=`Highest score till now is ${highestScore}`
// h2.insertAdjacentElement('afterend',h4);

    


 
