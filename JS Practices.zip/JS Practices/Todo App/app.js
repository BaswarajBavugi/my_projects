let ip=document.querySelector('input');
let btn=document.querySelector('button');
let tbl = document.querySelector('table');

btn.addEventListener("click",function(){
    // console.log("btn clicked");
    let row = document.createElement('tr');
    let data=document.createElement('td');
    data.innerText=ip.value;
    row.appendChild(data);
    let del=document.createElement('button');
    del.innerText='delete';
    row.appendChild(del);

    tbl.appendChild(row);
    ip.value="";    
});

// let btns=document.querySelectorAll('tr button');

// for(btn of btns){
//     btn.addEventListener('click',function(){
//         console.log("delete clicked");
//         this.parentElement.parentElement.remove();
//     });
// }

tbl.addEventListener('click',function(event){
    if(event.target.innerText=='delete'){
        let tdata= event.target.parentElement;
        tdata.remove();
    }
});